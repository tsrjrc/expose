#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h> //for px4's external pose estimate
#include <geometry_msgs/TransformStamped.h>
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
//EIGEN
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>

geometry_msgs::PoseStamped  zed_pose;

ros::Publisher px4_external_pose_estimate;
ros::Publisher fakegps_pose_estimate;
std::string map_frame, base_frame;
ros::Time init_time ;


Eigen::Quaterniond zed_q;
double zed_yawInRad=0;
double zedX=0;
double zedY=0;
double zedZ=0;
geometry_msgs::Vector3 toEulerAngle(geometry_msgs::Quaternion quat)
{
  geometry_msgs::Vector3 ans;

  tf::Matrix3x3 R_FLU2ENU(tf::Quaternion(quat.x, quat.y, quat.z, quat.w));
  R_FLU2ENU.getRPY(ans.x, ans.y, ans.z);
  return ans;
}

void zedposeHandler(const geometry_msgs::PoseStamped::ConstPtr& pose)
{
	Eigen::Vector3d zed;
	zed << pose->pose.position.x,pose->pose.position.y,pose->pose.position.z;
	zed_q.x() = pose->pose.orientation.x;
	zed_q.y() = pose->pose.orientation.y;
	zed_q.z() = pose->pose.orientation.z;
	zed_q.w() = pose->pose.orientation.w;
	zed_yawInRad = toEulerAngle(pose->pose.orientation).z;
	
 	Eigen::Vector3d zed_temp(0,0,0);
// 	zed_temp = (zed_q.inverse())*zed;
	Eigen::AngleAxisd Axis2 = Eigen::AngleAxisd(toEulerAngle(pose->pose.orientation).z,Eigen::Vector3d::UnitZ());
	Eigen::AngleAxisd Axis1 = Eigen::AngleAxisd(toEulerAngle(pose->pose.orientation).y,Eigen::Vector3d::UnitY());
	Eigen::AngleAxisd Axis0 = Eigen::AngleAxisd(toEulerAngle(pose->pose.orientation).x,Eigen::Vector3d::UnitX());
	
	zed_temp=Axis1.inverse()*Axis0.inverse()*zed;
	
 	zedX=zed_temp(0);
 	zedY=zed_temp(1);
 	zedZ=zed_temp(2);
	
	ROS_INFO("zedX:%f;zedY:%f;zedZ:%f",zedX,zedY,zedZ);
	
// 	geometry_msgs::TransformStamped fakegps_pose;
// 	fakegps_pose.header.frame_id = pose->header.frame_id;
// 	fakegps_pose.header.stamp = ros::Time::now();
// 	fakegps_pose.transform.rotation.x = pose->pose.orientation.x;
// 	fakegps_pose.transform.rotation.y = pose->pose.orientation.y;
// 	fakegps_pose.transform.rotation.z = pose->pose.orientation.z;
// 	fakegps_pose.transform.rotation.w = pose->pose.orientation.w;
// 
// 	//   pose_stamped.transform.translation.x = sin(yaw)*pose->pose.position.x+cos(yaw)*pose->pose.position.y;
// 	//   pose_stamped.transform.translation.y = -sin(yaw)*pose->pose.position.y+cos(yaw)*pose->pose.position.x;
// 	//   static float cnt = 0;
// 	//   cnt+=0.001;
// 	fakegps_pose.transform.translation.x = cos(yaw)*pose->pose.position.x-sin(yaw)*pose->pose.position.y;
// 	fakegps_pose.transform.translation.y = sin(yaw)*pose->pose.position.x+cos(yaw)*pose->pose.position.y;
// 
// 	fakegps_pose.transform.translation.z = pose->pose.position.z;
// 
// 	ROS_INFO("yaw:%f",yaw);
// 
// 	fakegps_pose_estimate.publish(fakegps_pose);
	//   geometry_msgs::PoseStamped pose_zed;
	//   pose_zed.header = pose->header;
	//   pose_zed.pose = pose->pose;
	//   
	//   px4_external_pose_estimate.publish(*pose);
}
void imuDataHandler(const sensor_msgs::Imu::ConstPtr& imuData)
{
  
  tf::Quaternion orientation;
  tf::quaternionMsgToTF(imuData->orientation, orientation);
//   tf::Matrix3x3(orientation).getRPY(roll, pitch, yaw);

//   ROS_INFO("yaw2:%f",yaw*180.0/3.1415);
}
// void globalDataHandler(const nav_msgs::Odometry::ConstPtr& globalData)
// {
//   double roll, pitch, yaw;
//   tf::Quaternion orientation;
//   tf::quaternionMsgToTF(globalData->pose.pose.orientation, orientation);
//   tf::Matrix3x3(orientation).getRPY(roll, pitch, yaw);
// 
//   
// }

int main(int argc, char **argv) {
    

    ros::init(argc, argv, "indoor_control_node");
    ros::NodeHandle nh;

    //NOTE For px4's external pose estimate
    px4_external_pose_estimate = nh.advertise<geometry_msgs::PoseStamped>("/mavros/vision_pose/pose",100);
    fakegps_pose_estimate = nh.advertise<geometry_msgs::TransformStamped>("/mavros/fake_gps/mocap/tf",100);
    ros::Subscriber zed_pose_sub = nh.subscribe<geometry_msgs::PoseStamped> ("/zed/zed_node/pose", 1000, zedposeHandler);
    ros::Subscriber imuDataSub = nh.subscribe<sensor_msgs::Imu> ("/mavros/imu/data", 50, imuDataHandler);
//     ros::Subscriber globalSub = nh.subscribe<nav_msgs::Odometry> ("/mavros/global_position/local", 50,globalDataHandler);
    
    init_time = ros::Time::now();
    ros::spin();

    
    return 0;
}


