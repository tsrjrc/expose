#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h> //for px4's external pose estimate
#include <geometry_msgs/TransformStamped.h>
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
//EIGEN
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>
//MAVROS
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <mavros_msgs/StreamRate.h>
#include <mavros_msgs/RCIn.h>
#include <mavros_msgs/AttitudeTarget.h>
geometry_msgs::PoseStamped  zed_pose;

ros::Publisher px4_external_pose_estimate;
ros::Publisher fakegps_pose_estimate;
ros::Publisher set_att;
std::string map_frame, base_frame;
ros::Time init_time ;


Eigen::Quaterniond zed_q;
double zed_yawInRad=0;
double zedX=0;
double zedY=0;
double zedZ=0;
geometry_msgs::Vector3 toEulerAngle(geometry_msgs::Quaternion quat)
{
  geometry_msgs::Vector3 ans;

  tf::Matrix3x3 R_FLU2ENU(tf::Quaternion(quat.x, quat.y, quat.z, quat.w));
  R_FLU2ENU.getRPY(ans.x, ans.y, ans.z);
  return ans;
}

void zedposeHandler(const geometry_msgs::PoseStamped::ConstPtr& pose)
{
	Eigen::Vector3d zed;
	zed << pose->pose.position.x,pose->pose.position.y,pose->pose.position.z;
	zed_q.x() = pose->pose.orientation.x;
	zed_q.y() = pose->pose.orientation.y;
	zed_q.z() = pose->pose.orientation.z;
	zed_q.w() = pose->pose.orientation.w;
	zed_yawInRad = toEulerAngle(pose->pose.orientation).z;
	
 	Eigen::Vector3d zed_temp(0,0,0);
// 	zed_temp = (zed_q.inverse())*zed;
	Eigen::AngleAxisd Axis2 = Eigen::AngleAxisd(toEulerAngle(pose->pose.orientation).z,Eigen::Vector3d::UnitZ());
	Eigen::AngleAxisd Axis1 = Eigen::AngleAxisd(toEulerAngle(pose->pose.orientation).y,Eigen::Vector3d::UnitY());
	Eigen::AngleAxisd Axis0 = Eigen::AngleAxisd(toEulerAngle(pose->pose.orientation).x,Eigen::Vector3d::UnitX());
  zed_temp=Axis2.inverse()*zed;
 	zedX=zed_temp(0);
 	zedY=zed_temp(1);
 	zedZ=zed_temp(2);
	
	ROS_INFO("zedX:%f;zedY:%f;zedZ:%f",zedX,zedY,zedZ);

  geometry_msgs::TransformStamped fakegps_pose;
  fakegps_pose.header.frame_id = pose->header.frame_id;
  fakegps_pose.header.stamp = ros::Time::now();
  fakegps_pose.transform.rotation.x = pose->pose.orientation.x;
  fakegps_pose.transform.rotation.y = pose->pose.orientation.y;
  fakegps_pose.transform.rotation.z = pose->pose.orientation.z;
  fakegps_pose.transform.rotation.w = pose->pose.orientation.w;
  fakegps_pose.transform.translation.x = pose->pose.position.x;
  fakegps_pose.transform.translation.y = pose->pose.position.y;
  fakegps_pose.transform.translation.z = pose->pose.position.z;
  fakegps_pose_estimate.publish(fakegps_pose);
	

}
void imuDataHandler(const sensor_msgs::Imu::ConstPtr& imuData)
{
  
  tf::Quaternion orientation;
  tf::quaternionMsgToTF(imuData->orientation, orientation);
//   tf::Matrix3x3(orientation).getRPY(roll, pitch, yaw);

}
mavros_msgs::State current_state;
void state_cb(const mavros_msgs::State::ConstPtr& msg)
{
    current_state = *msg;
}

void rc_cb(const mavros_msgs::RCIn::ConstPtr& msg)
{

  int gun_data = msg->channels[2];
  int yaw_data = msg->channels[3];
  int pitch_data = msg->channels[1];
  int roll_data = msg->channels[0];
  ROS_INFO("tr:%d,yaw_data:%d,pitch_data:%d,roll_data:%d",gun_data,yaw_data,pitch_data,roll_data);
}

int main(int argc, char **argv) {
    

    ros::init(argc, argv, "indoor_control_node");
    ros::NodeHandle nh;

    //NOTE For px4's external pose estimate
    px4_external_pose_estimate = nh.advertise<geometry_msgs::PoseStamped>("/mavros/vision_pose/pose",100);
    fakegps_pose_estimate = nh.advertise<geometry_msgs::TransformStamped>("/mavros/fake_gps/mocap/tf",100);
    ros::Subscriber zed_pose_sub = nh.subscribe<geometry_msgs::PoseStamped> ("/zed/zed_node/pose", 1000, zedposeHandler);
    ros::Subscriber imuDataSub = nh.subscribe<sensor_msgs::Imu> ("/mavros/imu/data", 50, imuDataHandler);

    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>("mavros/state", 10, state_cb);
    ros::Subscriber rc_sub = nh.subscribe<mavros_msgs::RCIn>("/mavros/rc/in", 50, rc_cb);
    set_att = nh.advertise<mavros_msgs::AttitudeTarget> ("/mavros/setpoint_raw/attitude",50);

    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>("mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>("mavros/set_mode");
    ros::ServiceClient set_rate_client = nh.serviceClient<mavros_msgs::StreamRate>("/mavros/set_stream_rate");


    //the setpoint publishing rate MUST be faster than 2Hz
    ros::Rate rate(20.0);
    // wait for FCU connection
    while(ros::ok() && !current_state.connected)
    {
       ros::spinOnce();
       rate.sleep();
    }
    mavros_msgs::StreamRate stream_rate;
    stream_rate.request.on_off = true;
    stream_rate.request.message_rate = 50;
    if(set_rate_client.call(stream_rate))
    {
      ROS_INFO("50 hz OK!!!!");
    }

    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "GUIDED_NOGPS";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time last_request = ros::Time::now();

    while(ros::ok())
    {
      if( current_state.mode != "GUIDED_NOGPS" && (ros::Time::now() - last_request > ros::Duration(5.0)))
      {
         if( set_mode_client.call(offb_set_mode) && offb_set_mode.response.mode_sent)
         {
             ROS_INFO("Guided_NoGPS enabled");
         }
         last_request = ros::Time::now();
      }
      else
      {
        if( !current_state.armed && (ros::Time::now() - last_request > ros::Duration(5.0)))
        {
          if( arming_client.call(arm_cmd) && arm_cmd.response.success)
          {
            ROS_INFO("Vehicle armed");
          }
          last_request = ros::Time::now();
          ROS_INFO("Vehicle armed ok");
        }
        else if(current_state.armed)
        {
          static int cnt=0;
          if(cnt < 200)
          {
            mavros_msgs::AttitudeTarget setatt;
            setatt.thrust = 0.55;
            setatt.type_mask = 0b00000000;
            set_att.publish(setatt);
            cnt++;
          }
          else
          {
            mavros_msgs::AttitudeTarget setatt;
            setatt.thrust = 0.4;
            setatt.type_mask = 0b00000000;
            set_att.publish(setatt);
          }
          ROS_INFO("%d",cnt);
        }
      }
      ros::spinOnce();
      rate.sleep();
    }
    
    return 0;
}


